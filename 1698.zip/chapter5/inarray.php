<?php
   $grades = array(100,94.7,67,89,100);
   if (in_array("100",$grades)) echo "Somebody studied for the test!";
   if (in_array("100",$grades,1)) echo "Somebody studied for the test!";
?>