<?php
   $states = array("Alabama", "Alaska", "Arizona", "Arkansas", "California", "Connecticut");
   $subset = array_splice($states, 2, -1, array("New York", "Florida"));
   print_r($states);
?>
