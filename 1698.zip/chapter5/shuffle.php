<?php
   $cards = array("jh","js","jd","jc","qh","qs","qd","qc","kh","ks","kd","kc","ah","as","ad","ac");
   // shuffle the cards
   shuffle($cards);
   print_r($positions);
?>
