<?php
   $states = array("Ohio","New York","California","Texas");
   $state = array_pop($states); // $state = "Texas"
   print_r($states);
?>