<?php
   $even = range(0,20,2);
   // $even = array(0,2,4,6,8,10,12,14,16,18,20);
   print_r($die);
?>