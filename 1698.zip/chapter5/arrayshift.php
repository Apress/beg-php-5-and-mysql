<?php
$states = array("Ohio","New York","California","Texas");
print "before shift:<br />";
print_r($states);
$state = array_shift($states);
// $states = array("New York","California","Texas")
// $state = "Ohio"
print "<br />after shift:<br />";
print_r($states);
?>