<?php
   $population = array("Ohio" => "11,421,267", "Iowa" => "2,936,760");
   $popvalues = array_values($population);
   print_r($popvalues);
   // Array ( [0] => 11,421,267 [1] => 2,936,760 )
?>