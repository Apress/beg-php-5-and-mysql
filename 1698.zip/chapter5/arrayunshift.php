<?php
$states = array("Ohio","New York");
print "before unshift:<br />";
print_r($states);
array_unshift($states,"California","Texas");
// $states = array("California","Texas","Ohio","New York");
print "<br />after unshift:<br />";
print_r($states);
?>