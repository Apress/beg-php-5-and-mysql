<?php
   $state["Delaware"] = "December 7, 1787";
   $state["Pennsylvania"] = "December 12, 1787";
   $state["New Jersey"] = "December 18, 1787";
   $keys = array_keys($state);
   print_r($keys);
   // Array ( [0] => Delaware [1] => Pennsylvania [2] => New Jersey )
?>