<?php
   $array1 = array("OH" => "Ohio", "CA" => "California", "HI" => "Hawaii");
   $array2 = array("50" => "Hawaii", "CA" => "California", "OH" => "Ohio");
   $array3 = array("TX" => "Texas", "MD" => "Maryland", "OH" => "Ohio");
   $intersection = array_intersect_assoc($array1, $array2, $array3);
   print_r($intersection);
?>
