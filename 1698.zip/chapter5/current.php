<?php
$fruits = array("apple", "orange", "banana");
print_r($fruits);
$fruit = current($fruits); // returns "apple"
echo "Fruit: $fruit<br />";
$fruit = next($fruits); // returns "orange"
echo "Fruit: $fruit<br />";
$fruit = prev($fruits); // returns "apple"
echo "Fruit: $fruit<br />";
?>