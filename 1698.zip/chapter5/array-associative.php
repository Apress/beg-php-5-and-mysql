<?php

$languages = array ("Spain" => "Spanish",
                                 "Ireland" => "Gaelic",
                                 "United States" => "English");

print_r($languages);

?>
