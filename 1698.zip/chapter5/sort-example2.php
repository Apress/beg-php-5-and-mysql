<?php
   $states = array("OH" => "Ohio", "CA" => "California", "MD" => "Maryland");
   sort($states);
   print_r($states);
?>