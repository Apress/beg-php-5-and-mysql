<?php
   $states = array("Alaska","Hawaii");
   print "before pad:<br />";
   print_r($states);
   $states = array_pad($states,4,"New colony?");
   $states = array("Alaska","Hawaii","New colony?","New colony?");
   print "<br />after pad:<br />";
   print_r($states);
?>