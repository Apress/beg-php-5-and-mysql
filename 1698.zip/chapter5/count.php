<?php
   $locations = array("Italy","Amsterdam",array("Boston","Des Moines"),"Miami");
   echo count($locations,1);
?>