<?php
   $abbreviations = array("AL","AK","AZ","AR");
   $states = array("Alabama","Alaska","Arizona","Arkansas");
   $stateMap = array_combine($abbreviations,$states);
   print_r($stateMap);
?>
