<?php
   $grades = array(42,"hello",42);
   $total = array_sum($grades);
   print $total;
?>
