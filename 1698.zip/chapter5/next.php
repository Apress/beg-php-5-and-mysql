<?php
   $fruits = array("apple", "orange", "banana");
   print_r($fruits);
   $fruit = next($fruits); // returns "orange"
   echo "Next fruit: $fruit<br />";
   $fruit = next($fruits); // returns "banana"
   echo "Next fruit: $fruit<br />";
?>