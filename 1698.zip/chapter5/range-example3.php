<?php
   $letters = range("A","F");
   // $letters = array("A,","B","C","D","E","F");
   print_r($letters);
?>