<?php
   $die = range(0,6);
   // Same as specifying $die = array(0,1,2,3,4,5,6)
   print_r($die);
?>