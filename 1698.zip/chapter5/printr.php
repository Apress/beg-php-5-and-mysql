<?php
$states = array (
"Ohio" => array ("population" => "11,353,140", capital => "Columbus"),
"Nebraska" => array("population" => "1,711,263", capital => "Omaha")
)

print_r($states);

?>
