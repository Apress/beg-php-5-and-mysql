<?php
   $state["Ohio"] = "March 1";
   $state["Delaware"] = "December 7";
   $state["Pennsylvania"] = "December 12";
   $founded = array_search("December 7", $state);
   if ($founded) echo "The state $founded was founded on $state[$founded]";
?>