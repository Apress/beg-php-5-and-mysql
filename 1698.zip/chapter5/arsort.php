<?php
   $states = array("Delaware","Pennsylvania","New Jersey");
   arsort($states);
   print_r($states);
   // Array ( [1] => Pennsylvania [2] => New Jersey [0] => Delaware )
?>
