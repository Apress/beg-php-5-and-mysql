<?php
// While the EOF hasn't been reached, get next line
while ($line = fgets ($user_file, 4096)) {
// use explode() to separate each piece of data.
list ($name, $occupation, $color) = explode ("|", $line);
// format and output the data
print "Name: $name <br />";
print "Occupation: $occupation <br />";
print "Favorite color: $color <br />";
}
?>