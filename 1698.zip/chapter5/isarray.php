<?php
   $states = array("Florida");
   $state = "Ohio";
   echo "\$states is an array: ".is_array($states)."<br />";
   echo "\$state is an array: ".is_array($state)."<br />";
?>