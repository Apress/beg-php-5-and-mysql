<?php
   $states = array("Ohio","Florida","Massachusetts","Montana");
   sort($states);
   print_r($states)
   // Array ( [0] => Ohio [1] => Montana [2] => Massachusetts [3] => Florida )
?>