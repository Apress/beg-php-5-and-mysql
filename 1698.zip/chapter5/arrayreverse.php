<?php
   $states = array("Delaware","Pennsylvania","New Jersey");
   print "Before reverse: <br />";
   print_r($states);
   print "<br />After reverse: <br />";
   print_r(array_reverse($states));
?>