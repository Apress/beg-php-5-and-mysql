<form action="submitdata.php" method="post">
   <p>
      Provide up to six keywords that you believe best describe the state in which you live:
   </p>
   <p>Keyword 1:<br />
      <input type="text" name="keyword[]" size="20" maxlength="20" value="" />
   </p>
   <p>Keyword 2:<br />
      <input type="text" name="keyword[]" size="20" maxlength="20" value="" />
   </p>
   <p>Keyword 3:<br />
      <input type="text" name="keyword[]" size="20" maxlength="20" value="" />
   </p>
   <p>Keyword 4:<br />
      <input type="text" name="keyword[]" size="20" maxlength="20" value="" />
   </p>
   <p>Keyword 5:<br />
      <input type="text" name="keyword[]" size="20" maxlength="20" value="" />
   </p>
   <p>Keyword 6:<br />
      <input type="text" name="keyword[]" size="20" maxlength="20" value="" />
   </p>
   <p>
      <input type="submit" value="Submit!">
   </p>
</form>
