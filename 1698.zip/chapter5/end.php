<?php
$fruits = array("apple", "orange", "banana");
print_r($fruits);
$fruit = current($fruits); // returns "apple"
echo "Current: $fruit<br />";
$fruit = end($fruits); // returns "banana"
echo "End: $fruit<br />";
?>