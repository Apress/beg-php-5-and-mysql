<?php

   phpinfo();

?>