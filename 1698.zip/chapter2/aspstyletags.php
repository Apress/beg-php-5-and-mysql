<%
   echo "Some PHP statement";
%>