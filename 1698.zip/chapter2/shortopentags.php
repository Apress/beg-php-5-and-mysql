<?php
   echo "Some PHP statement";
?>