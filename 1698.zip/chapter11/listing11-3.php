<?

   // The revised create_crumbs() function. Note that this version is
   // much simpler, as it's customized specifically for use with the book catalog.
   function create_crumbs($siteURL, $categoryID, $categoryName, $title) {
      $crumb = "<a href = \"$siteURL\">Home</a> &gt;<a href = \"$siteURL/category/$categoryID/\">$categoryName</a> &gt; $title";
      print $crumb;
   } # end create_crumbs definition

   $siteURL = "http://www.example.com";

   // connect to the db server and select the database
   mysql_pconnect("localhost","jason","secret");
   mysql_select_db("chapter11");

   // Assume that this would be parsed from the user-friendly URL
   $isbn = "1893115852";

   // Execute the query. To improve performance, this same query could also
   // be used to retrieve the book data for the page.
   $result = mysql_query("SELECT b.categoryID, c.categoryName, b.isbn,
                                         b.authorID, b.title, b.description
                                         FROM books b, bookCategories c
                                         WHERE b.isbn = $isbn AND
                                         b.categoryID = c.categoryID");
   $row = mysql_fetch_assoc($result);

   // Retrieve the query values
   $categoryID = $row["categoryID"];
   $categoryName = $row["categoryName"];
   $isbn = $row["isbn"];
   $authorID = $row["authorID"];
   $title = $row["title"];

   // Execute the function
   create_crumbs($siteURL, $categoryID, $categoryName, $title);
?>
