create table bookCategories (
   categoryID mediumint unsigned not null auto_increment,
   categoryName varchar(15) not null,
   primary key(categoryID));
