create table books (
   bookID mediumint unsigned not null auto_increment,
   categoryID mediumint unsigned not null,
   isbn varchar(10) not null,
   authorID mediumint unsigned not null,
   title varchar(45) not null,
   description mediumtext not null,
   primary key(bookID));
