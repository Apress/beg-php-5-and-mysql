<?php

   # Define a base Employee class
   class Employee {

      private $name;

      # Define a setter for the private $name member.
      function setName($name) {
         if ($name == "") echo "Name cannot be blank!";
            else $this->name = $name;
      }

      # Define a getter for the private $name member
      function getName() {
         return "My name is ".$this->name."<br />";
      }

   } #end Employee class

   # Define an Executive class that inherits Employee

   class Executive extends Employee {
      # Define a method unique to Employee
      function pillageCompany() {
         echo "I'm selling company assets to finance my yacht!";
      }

      class CEO extends Executive {
         function getFacelift() {
            echo "nip nip tuck tuck";
         }
      }

      $ceo = new CEO();
      $ceo->setName("Bernie");
      $ceo->pillageCompany();
      $ceo->getFacelift();

?>
