<?php

   /* Connect to the MySQL server and select the cars database. */
   $conn = mysql_connect("localhost","someuser","secret");
   $db = mysql_select_db("cars");

   /* Open and parse the cars.csv file. */
   $fh = fopen("cars.csv", "r");
   while ($line = fgetcsv($fh, 1000, ",")) {
      $year = $line[0];
      $make = $line[1];
      $color = $line[2];

      /* Insert the data into the carcollection table. */
      $query = "INSERT INTO carcollection SET year='$year', make='$make',color='$color'";
      $result = mysql_query($query);
   }

   fclose($fh);
   mysql_close();
?>
