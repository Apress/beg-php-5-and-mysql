<?php

   class Staff
   {
      private $name;

      public function setName($name) {
         $this->name = $name;
     }
   }

   $staff = new Staff;
   $staff->setName("Mary");

?>