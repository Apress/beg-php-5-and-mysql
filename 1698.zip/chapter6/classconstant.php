<?php

   class math_functions
   {
   const PI = '3.14159265';
   const E = '2.7182818284';
   const EULER = '0.5772156649';
   /* define other constants and methods here... */
   }

   echo math_functions::PI;

?>