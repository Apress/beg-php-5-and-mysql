<?php

   abstract class Staff
   {
      abstract function hire();
      abstract function fire();
      abstract function promote();
      abstract demote();
   }

?>
