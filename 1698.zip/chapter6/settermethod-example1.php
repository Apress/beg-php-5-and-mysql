<?php
   class Staff
   {
      var $name;
      function __set($propName, $propValue)
      {
         echo "Nonexistent variable: \$$propName!";
      }
   }

   $employee = new Staff();
   $employee->name = "Mario";
   $employee->title = "Executive Chef";

?>