<?php

   class visitors
   {
      private static $visitors = 0;

      function __construct()
      {
         self::$visitors++;
      }

      static function getVisitors()
      {
         return self::$visitors;
      }

   }

   /* Instantiate the visitors class. */
   $visits = new visitors();
   echo visitors::getVisitors()."<br />";

   /* Instantiate another visitors class. */
   $visits2 = new visitors();
   echo visitors::getVisitors()."<br />";

?>
