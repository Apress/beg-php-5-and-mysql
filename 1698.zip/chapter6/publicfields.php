<?php

   class Staff
   {
      public $name;
      /* Other field and method declarations follow... */
   }

   $employee = new Staff();
   $employee->name = "Mary Swanson";
   $name = $employee->name;
   echo "New staff member: $name";

?>