<?php
   $val = "secret";
   echo "Pre-hash string: $val <br />";
   $hash_val = md5 ($val);
   echo "Hashed outcome: $hash_val";
?>
