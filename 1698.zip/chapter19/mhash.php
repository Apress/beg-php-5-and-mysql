<?php
   $userpswd = "mysecretpswd";
   echo "The plaintext password is: $usepswd <br />";
   $pswdhash = mhash(MHASH_SHA1, $userpswd);
   echo "The hashed password is: ".bin2hex($pswdhash);
?>
