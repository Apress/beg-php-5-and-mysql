<?php
   // Reference the Smarty class library.
   require("smarty/Smarty.class.php");

   $smarty = new Smarty;
   $smarty->assign("title","Snow Expected in Northeast");
   $smarty->assign("filed","1072125525");
   $smarty->display("dateformat.tpl");

?>
