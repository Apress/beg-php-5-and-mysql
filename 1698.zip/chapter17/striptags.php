<?php
   // Reference the Smarty class library.
   require("smarty/Smarty.class.php");

   $smarty = new Smarty;
   $smarty->assign("title","Snow <strong>Expected</strong> in Northeast");
   $smarty->display("striptags.tpl");

?>
