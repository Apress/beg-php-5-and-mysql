<?php
   require("smarty/Smarty.class.php");
   $smarty = new Smarty;

   $titles = array(
      "A Programmer's Introduction to PHP 4.0",
      "Practical Python",
      "The Definitive Guide to MySQL"
   );

   $smarty->assign("titles",$titles);
   $smarty->display("titles.tpl");

?>