<?php
   // Reference the Smarty class library.
   require("smarty/Smarty.class.php");

   $smarty = new Smarty;
   $smarty->assign("title","Snow Expected in Northeast");
   $smarty->display("default.tpl");

?>
