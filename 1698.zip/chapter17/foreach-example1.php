<?php
   require("smarty/Smarty.class.php");
   $smarty = new Smarty;

   $daysofweek = array("Mon.","Tues.","Weds.","Thurs.","Fri.","Sat.","Sun.");
   $smarty->assign("daysofweek", $daysofweek);
   $smarty->display("daysofweek.tpl");

?>
