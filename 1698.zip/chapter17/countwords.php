<?php
   // Reference the Smarty class library.
   require("smarty/Smarty.class.php");

   $smarty = new Smarty;
   $smarty->assign("title", "Snow Expected in Northeast.");
   $smarty->assign("body", "More than 12 inches of snow is expected to accumulate overnight in New York.");
   $smarty->display("countwords.tpl");

?>
