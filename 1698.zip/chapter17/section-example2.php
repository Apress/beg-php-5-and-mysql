<?php
   require("smarty/Smarty.class.php");
   $smarty = new Smarty;

   // Create the array
   $titles[] = array(
      "title" => "A Programmer's Introduction to PHP 4.0",
      "author" => "Jason Gilmore",
      "published" => "2001"
   );

   $titles[] = array(
      "title" => "Practical Python",
      "author" => "Magnus Lie Hetland",
      "published" => "2002"
   );

   $smarty->assign("titles", $titles);
   $smarty->display("section2.tpl");

?>