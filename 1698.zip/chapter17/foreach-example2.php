<?php
   require("smarty/Smarty.class.php");
   $smarty = new Smarty;

   $states = array("OH" => "Ohio", "CA" => "California", "NY" => "New York");
   $smarty->assign("states",$states);
   $smarty->display("states.tpl");

?>