<?php
   // Reference the Smarty class library.
   require("smarty/Smarty.class.php");

   $summaries = array(
                          "Snow expected in the Northeast over the weekend.",
                          "Sunny and warm weather expected in Hawaii.",
                          "Softball-sized hail reported in Wisconsin."
                          );
   $smarty = new Smarty;
   $smarty->assign("summaries", $summaries);
   $smarty->display("truncate.tpl");

?>
