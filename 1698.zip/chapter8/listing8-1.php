<?php

   try {
      $conn = mysql_connect("localhost","webuser","secret");
         if (! $conn) {
            throw new Exception("Could not connect!");
        }
   }
   catch (Exception $e) {
      echo "Error (File: ".getFile().", line ".$e->getLine()."): ".$e->getMessage();
   }

?>
