<?php
   define_syslog_variables();
   openlog("CHP8", LOG_PID, LOG_USER);
   syslog(LOG_WARNING,"Chapter 8 example warning.");
   closelog();
?>
