CREATE TABLE quotation (
   id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
   boxer varchar(30) NOT NULL,
   quote MEDIUMTEXT NOT NULL,
   year YEAR NOT NULL,
   PRIMARY KEY(id)
>);
