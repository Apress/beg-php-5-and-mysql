<?php
   $xml = simplexml_load_file("books-v2.xml");
   foreach($xml->book[2]->cast->children() AS $character) {
      echo "$character<br />";
   }
?>
