<?php

   // Reference the nusoap class
   require_once('nusoap/nusoap.php');

   // Define the Web service's WSDL
   $serviceWSDL = "http://www.xmethods.net/sd/TemperatureService.wsdl";

   // Define the zip code
   $zipcode = "43210";

   // All parameters must be passed as an array
   $parameters = array('zipcode'=>$zipcode);

   // Create a new soapclient object which references the Web Service.
   $soapclient = new soapclient($serviceWSDL, 'wsdl');
  
   // Invoke the Web service's getTemp() method, returning the requested temperature
   $temperature = $soapclient->call('getTemp', $parameters);
   echo "It's $temperature degrees at zip code $zipcode.";

?>
