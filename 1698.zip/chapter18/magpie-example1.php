<?php
   require("magpie/rss_fetch.inc");
   $url = "http://localhost/pmnp/18/boxing.xml";
   $rss = fetch_rss($url);
   print_r($rss);
?>
