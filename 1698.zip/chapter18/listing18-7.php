<?php

   require_once('nusoap/nusoap.php');

   $serviceWSDL = "http://www.xmethods.net/sd/2001/TemperatureService.wsdl";
   $zipcode = "43210";
   
   // Create the Proxy
   $soapclient = new soapclient($serviceWSDL, 'wsdl');
   $proxy = $soapclient->getProxy();

   // Call the getTemp() method
   $temperature = $proxy->getTemp($zipcode);

   // Output the result
   echo "It's $temperature degrees at zip code $zipcode.";

?>
