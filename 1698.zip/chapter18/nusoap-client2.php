<?php

   require_once('nusoap/nusoap.php');

   // Always create a parameter array
   $params = array();

   // Create a new SOAP client
   $client = new soapclient("http://localhost/pmnp/18/boxing.php");

   // Execute the remote method retrieveBio()
   $boxer = $client->call('retrieveBio', $params);

   // Parse the returned associative array
   $name = $boxer["name"];
   $age = $boxer["age"];
   $bio = $boxer["bio"];

   // Output the information
   echo "<strong>$name</strong> ($age years)<br />$bio";

?>
