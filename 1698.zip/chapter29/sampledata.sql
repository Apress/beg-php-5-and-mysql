INSERT INTO participant SET name=�Jason�, email=�jason@example.com�, cash=�100.00�;
INSERT INTO participant SET name=�Jon�, email=�jon@example.com�, cash=�150.00�;
INSERT INTO trunk SET owner=2, name="Abacus", price=�12.99�, description="Low on computing power? Use an abacus!";
INSERT INTO trunk SET owner=2, name="Magazines", price=�6.00�, description="Stack of computer magazines.";
INSERT INTO trunk SET owner=1, name="Lottery ticket", price=�1.00�, description="Great gift for the eternal optimist.";
