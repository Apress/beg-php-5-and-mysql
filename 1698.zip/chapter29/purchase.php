<?php
   session_start();
   include "mysql.class.php";

   /* Retrieve the participant's primary key using some fictitious
      class that refers to some sort of user session table,
      mapping a session ID back to a specific user.
   */
   $participant = new participant();
   $buyerid = $participant->getparticipantkey();

   /* Give the POSTed item id a friendly variable name */
   $itemid = $_POST['itemid'];

   /* Retrieve the item seller and price using some fictitious item class. */
   $item = new item();
   $sellerid = $item->getitemowner ($itemid);
   $price = $item->getprice($itemid);

   // Instantiate the mysql class
   $mysqldb = new mysql("localhost","webuser","secret","company");

   // Connect to the MySQL server and select the database
   $mysqldb->connect();
   $mysqldb->select();

   // Start by assuming the transaction operations will all succeed
   $transactionsuccess = TRUE;

   // Start the transaction
   $mysqldb->begintransaction();

   /* Debit buyer's account. */
   $query = "UPDATE participant SET cash=cash-$price WHERE rowID='$buyerid'";
   $result = $mysqldb->query($query) ;
   if (!$result OR $result->affectedrows() != 1 )
      $transactionsuccess = FALSE;
   /* Credit seller's account. */
   $query = "UPDATE participant SET cash=cash+$price WHERE rowID='$sellerid'";
   $result = $mysqldb->query($query) ;

   if (!$result OR $result->affectedrows() != 1 )
      $transactionsuccess = FALSE;
      /* Update trunk item ownership. If it fails, set
      $transactionsuccess to FALSE. */
      $query = "UPDATE trunk SET owner=�$buyerid� WHERE rowid='$itemid'";
      $result = $mysqldb->query($query) ;

     if (!$result OR $result->affectedrows() != 1 )
        $transactionsuccess = FALSE;

     /* If $transactionsuccess is TRUE, commit the transaction, otherwise roll back the changes. */
     if ($transactionsuccess) {
        $mysqldb->commit();
        echo "The swap took place! Congratulations!";
     } else {
        $mysqldb->rollback();
        echo "There was a problem with the swap!";
     }

?>
