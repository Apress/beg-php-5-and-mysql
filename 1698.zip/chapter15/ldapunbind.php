<?php

   /* Designate connecting user and password. */
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";

   /* Connect and bind to the server. */
   $ldapLink = ldap_connect("ldap://ad.wjgilmore.com", 389) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink,"ldapreadonly", "iloveldap") or die("Can't bind to LDAP.");

   /* Execute various LDAP-related commands... */

   /* Close the server connection. */
   ldap_unbind($ldapLink) or die("Could not unbind from LDAP server.");

?>
