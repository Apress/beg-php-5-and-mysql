<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* Specify the distinguished name. */
   $dn = "OU=People, OU=staff, DC=ad, DC=wjgilmore, DC=com";

   /* Execute the search. */
   $results = ldap_search($ldapconn, $dn, "sn=G*", array(telephoneNumber, mail));

   /* Retrieve the first entry. */
   $entry = ldap_first_entry($ldapconn, $results);

   /* Retrieve and output the attribute name representing the first entry. */
   $fAttr = ldap_first_attribute($ldapconn, $entry, $pointer);
   echo $fAttr;

?>
