<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* What are we modifying? */
   $dn = CN=Julius Caesar,OU=People,OU=staff,DC=ad,DC=wjgilmore,DC=com";

   /* Delete just the company attribute found in the DN. */
   ldap_mod_delete($ldapconn, $dn, array("company"));

   /* Close the connection. */
   ldap_unbind($ldapconn);

?>
