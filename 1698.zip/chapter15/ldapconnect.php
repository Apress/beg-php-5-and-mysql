<?php

   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapLink = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");

?>
