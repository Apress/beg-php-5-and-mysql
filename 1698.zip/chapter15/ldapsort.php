<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* Specify the distinguished name. */
   $dn = "OU=People,OU=staff,DC=ad,DC=wjgilmore,DC=com";

   /* Search the directory */
   $results = ldap_search($ldapconn, $dn, "sn=G*", array("givenname", "sn"));

   /* Sort the entries. */
   ldap_sort($ldapconn, $results, "givenName");

   // Retrieve the sorted entries
   $entries = ldap_get_entries($ldapconn,$results);

   /* Output the givenname and sn of each entry. */
   $count = $entries["count"];
   for($i=0;$i<$count;$i++) {
      echo $entries[$i]["givenname"][0]." ".$entries[$i]["sn"][0]."<br />";
   }

   /* Close the connection. */
   ldap_unbind($ldapconn);

?>
