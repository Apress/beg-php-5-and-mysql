<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* Specify the distinguished name. */
   $dn = "CN=Jason Gilmore, OU=People, OU=staff, DC=ad, DC=wjgilmore, DC=com";

   /* What attributes do we want to retrieve? */
   $attributes = array("sn","telephonenumber");

   /* Designate a filter. */
   $filter = "memberof=CN=staff,OU=Groups, DC=ad,DC=wjgilmore,DC=com";

   /* Execute the search. */
   $result = ldap_search($ldapconn, $dn, $filter, $attributes);

   /* Cycle through the entries. */
   $entry = ldap_first_entry($ldapconn, $result);
   while($entry) {
      $attrs = ldap_get_attributes($ldapconn, $entry);
      for ($i=0; $i<$attrs["count"]; $i++) {
         $attrName = $attrs[$i];
         $values = ldap_get_values($ldapconn,$entry,$attrName);

         for ($j=0; $j < $values["count"]; $j++) {
            echo "$attrName: ".$values[$j]."<br />";
         }
      }

      $entry = ldap_next_entry($ldapconn,$entry);
   }

?>
