<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* Specify the distinguished name. */
   $dn = CN=Julius Caesar,OU=People,OU=staff,DC=ad,DC=wjgilmore,DC=com";

   /* Add another email address. */
   $entry["mail"][] = "ides@wjgilmore.com";

   /* Add the additional e-mail address to the entry specified by the DN. */
   ldap_mod_add($ldapconn, $dn, $entry) or die("Can't add entry attribute value!");

   /* Close the connection. */
   ldap_unbind($ldapconn);

?>
