<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* Specify the distinguished name. */
   $dn = "CN=Jason Gilmore, OU=People, OU=staff, DC=ad, DC=wjgilmore, DC=com";

   /* Search for entitles of objectclass person. Specifically retrieve just the givenName, sn, and mail attributes. */
   $results = ldap_read($ldapconn, $dn, '(objectclass=person)', array("givenName", "sn", "mail"));

   /* Retrieve the person's first name, last name and email address(es). */
   $firstname = ldap_get_values($ldapconn, $results, "givenname");
   $lastname = ldap_get_values($ldapconn, $results, "sn");
   $mail = ldap_get_values($ldapconn, $results, "mail");

   /* Output the retrieved person's first and last name. */
   echo "First name: ".$firstname[0]."<br />";
   echo "Last name: ".$lastname[0]."<br />";
   echo "Email addresses: ";

   /* Output the retrieved person's email addresses. */
   $x=0;
   while ($x < $mail["count"]) {
      echo $mail[$x]. " ";
      $x++;
   }
?>
