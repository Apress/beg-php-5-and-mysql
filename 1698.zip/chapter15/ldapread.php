<?php

   /* Connect and bind to the LDAP server.... */
   $dn = "CN=Jason Gilmore, OU=People, OU=staff, DC=ad, DC=wjgilmore, DC=com";

   $results = ldap_read($ldapconn, $dn, '(objectclass=person)', array("givenName", "sn"));

   /* Retrieve the entries. */
   $entry = ldap_get_entries($ldapconn, $sr);

   /* Output the first and last name of the person located in the first entry of the results. */
   echo "First name: ".$entry[0]["givenname"][0]."<br />";
   echo "Last name: ".$entry[0]["sn"][0]."<br />";

   /* Close the connection. */
   ldap_unbind($ldapconn);

?>
