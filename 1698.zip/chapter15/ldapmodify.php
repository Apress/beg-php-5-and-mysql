<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* What are we modifying? */
   $dn = CN=Julius Caesar,OU=People,OU=staff,DC=ad,DC=wjgilmore,DC=com";

   /* Specify the attributes to be modified. */
   $attrs = array("Company" => "Roman Empire", "Title" => "Pontifex Maximus");

   /* Modify the entry. */
   ldap_modify($ldapconn, $dn, $attrs);

   /* Close the connection. */
   ldap_unbind($ldapconn);

?>
