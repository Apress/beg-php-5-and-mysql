<?php
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapLink = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");
?>
