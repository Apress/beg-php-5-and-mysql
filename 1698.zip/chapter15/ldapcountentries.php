<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* Specify the distinguished name. */
   $dn = "OU=People, OU=staff, DC=ad, DC=wjgilmore, DC=com";

   /* Execute a search based on the distinguished name, returning only those
      entries where the sn begins with 'G'. */
   $results = ldap_search($ldapconn, $dn, "sn=G*");

   /* Retrieve and output the number of entries retrieved. */
   $count = ldap_count_entries($ldapconn, $results);
   echo "<p>Total entries retrieved: $count</p>";

?>
