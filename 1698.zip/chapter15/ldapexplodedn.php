<?php

   /* Specify the DN. */
   $dn = "OU=People,OU=staff,DC=ad,DC=wjgilmore,DC=com";

   /* Parse the DN. */
   $dnComponents = ldap_explode_dn($dn, 0);

   /* Output each part of the DN. */
   foreach($dnComponents as $component) {
      echo $component."<br />";
   }

?>
