<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* Specify the distinguished name. */
   $dn = "CN=Jason Gilmore, OU=People, OU=staff, DC=ad, DC=wjgilmore, DC=com";

   /* What attributes do we want to retrieve? */
   $attributes = array("sn","telephonenumber");

   /* Designate a filter. */
   $filter = "memberof=CN=staff,OU=Groups, DC=ad,DC=wjgilmore,DC=com";

   /* Execute the search. */
   $results = ldap_search($ldapconn, $dn, "sn=G*",array(telephoneNumber, userPrincipalName, mail));

   /* Retrieve the first entry and subsequently, the attribute. 
       Note that this is required in order to use ldap_next_attribute(). */
   $entry = ldap_first_entry($ldapconn, $results);
   $attr = ldap_first_attribute($ldapconn, $entry, $pointer);

   /* Cycle through all subsequent attributes. */
   while ($attr = ldap_next_attribute($ldapconn, $entry, $pointer)) echo $attr."<br />";


?>
