<?php

   /* Connect and bind to the LDAP server.... */
   $ldapHost = "ldap://ad.gilmore.com";
   $ldapPort = "389";
   $ldapUser = "ldapreadonly";
   $ldapPswd = "iloveldap";
   $ldapconn = ldap_connect($ldapHost, $ldapPort) or die("Can't establish LDAP connection");
   ldap_bind($ldapLink, $ldapUser, $ldapPswd) or die("Can't bind to the server.");

   /* Specify the distinguished name. */
   $dn = "CN=Jason Gilmore, OU=People, OU=staff, DC=ad, DC=wjgilmore, DC=com";

   /* What phone number are we comparing to the retrieved result? */
   $phone = "614 555-1234";

   /* Execute the comparison. */
   if (ldap_compare($ldapconn, $dn, "homePhone", $phone)) {
      echo "<p>Your phone number is up-to-date</p>";
   } else {
      echo "<p>The entered phone number does not match our records. Perhaps you've recently moved?</p>" ;
   }

?>
