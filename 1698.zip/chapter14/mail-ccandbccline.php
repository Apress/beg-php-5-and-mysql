<?php
   echo "<p>Note to reader: You must replace the placeholder e-mail addresses used in this example with your own in order to view the results.</p>";
   $headers = "From:sender@example.com\r\n";
   $recipients = "test@example.com,info@example.com";
   mail($recipients, "This is the subject","This is the mail body", $headers);
?>
