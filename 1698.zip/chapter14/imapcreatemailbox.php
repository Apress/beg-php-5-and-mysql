<?php

   echo "<p>Note to reader: You must replace the placeholder e-mail addresses used in this example with your own in order to view the results.</p>";

   $mailserver = "{imap.example.com:143/imap/notls}INBOX";
   $mbox = "events";
   $ms = imap_open($mailserver,"jason","mypswd");
   imap_createmailbox($ms,$mailserver."/".$mbox);
   imap_close($ms);

?>
   



