<?php

   echo "<p>Note to reader: You must replace the placeholder e-mail addresses used in this example with your own in order to view the results.</p>";

   // Open an IMAP connection
   $ms = imap_open("{imap.example.com:143/imap/notls}","jason","mypswd");

   // Open a POP3 connection
   $ms = imap_open("{pop3.example.com:110/pop3/notls}","jason","mypswd");

   // Open an NNTP connection
   $ns = imap_open("{nntp.example.com:119/nntp}","jason","mypswd");

?>
