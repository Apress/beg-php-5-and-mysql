<?php

   echo "<p>Note to reader: You must replace the placeholder e-mail addresses used in this example with your own in order to view the results.</p>";

   include("mimemail/htmlMimeMail.php");

   // Set the From and Reply-To headers
   $mail->setFrom('Jason <author@example.com>');
   $mail->setReturnPath('author@example.com');

   // Set the Subject
   $mail->setSubject('Test with attached email');

   // Set the body
   $mail->setText("Please find attached Chapter 14. Thank you!");

   // Retrieve a file for attachment
   $attachment = $mail->getFile('chapter14.doc');

   // Attach the file, assigning it a name and a corresponding Mime-type.
   $mail->addAttachment($attachment, 'chapter14.doc', 'application/vnd.ms-word');

   // Send the email to editor@example.com
   $result = $mail->send(array('editor@example.com'));

?>