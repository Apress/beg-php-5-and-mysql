<?php
     echo "<p>Note to reader: You must replace the placeholder e-mail addresses used in this example with your own in order to view the results.</p>";
   mail("test@example.com", "This is a subject", "This is the mail body");
?>
