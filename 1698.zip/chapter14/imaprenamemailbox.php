<?php

   echo "<p>Note to reader: You must replace the placeholder IMAP server and e-mail addresses used in this example with your own in order to view the results.</p>";

   $mbox = "{imap.example.com:143/imap/notls}INBOX";
   if (imap_renamemailbox($ms, "$mbox/staff", "$mbox/teammates"))
      echo "The mailbox has successfully been renamed";
   else
      echo "There was a problem renaming the mailbox";
?>
