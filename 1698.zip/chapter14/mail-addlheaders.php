<?php
   echo "<p>Note to reader: You must replace the placeholder e-mail addresses used in this example with your own in order to view the results.</p>";
   $headers = "From:sender@example.com\r\n";
   $headers .= "Reply-To:sender@example.com\r\n";
   $headers .= "Content-Type: text/plain;\r\n charset=iso-8859-1\r\n";
   mail("test@example.com", "This is the subject", "This is the mail body", $headers);
?>
