<?php

   echo "<p>Note to reader: You must replace the placeholder e-mail addresses used in this example with your own in order to view the results.</p>";

   // Open an IMAP connection
   $user = "jason";
   $pswd = "mypswd";
   $ms = imap_open("{imap.example.com:143}INBOX",$user, $pswd);

   // Retrieve total number messages
   $msgnum = imap_num_msg($ms);
   echo "<p>User $user has $msgnum messages in his inbox.</p>";

?>
