<?php
   echo "Port 80's default service is: ".getservbyport(80, "tcp");
?>
