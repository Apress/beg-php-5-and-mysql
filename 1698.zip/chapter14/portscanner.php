<?php
   $target = "www.example.com";
   echo "<pre>";
      system("/usr/bin/nmap $target");
   echo "</pre>";

   // Kill the task
   system("killall -q nmap");
?>
