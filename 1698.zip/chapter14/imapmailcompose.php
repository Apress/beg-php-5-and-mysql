<?php

   echo "<p>Note to reader: You must replace the placeholder e-mail addresses used in this example with your own in order to view the results.</p>";

   $envelope["from"] = "gilmore@example.com";
   $envelope["to"] = "admin@example.com";
   $msgpart["type"] = TYPETEXT;
   $msgpart["subtype"] = "plain";
   $msgpart["contents.data"] = "This is the message text.";
   $msgbody[1] = $msgpart;
   echo nl2br(imap_mail_compose($envelope,$msbody));
?>



