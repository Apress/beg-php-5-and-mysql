<?php
   print_r(stream_get_filters());
?>
