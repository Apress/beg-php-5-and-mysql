<?php
   $recordexists = checkdnsrr("example.com", "ANY");
   if ($recordexists) 
      echo "The domain name has been taken. Sorry!";
   else 
      echo "The domain name is available!";
?>
