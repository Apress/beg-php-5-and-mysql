<?php

   @mysql_connect("localhost", "webuser", "secret") or die("Could not connect to MySQL server!");

   @mysql_select_db("company") or die("Could not select database!");


   $query = "SELECT productid, name FROM product ORDER BY name";
   $result = mysql_query($query);

   $productid = mysql_result($result, 0, "productid");
   $name = mysql_result($result, 0, "name");
   echo "The first returned product id is $productid and the name is $name";
?>
