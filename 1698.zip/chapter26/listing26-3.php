<form action="modify.php" method="post">
   <select name="rowID">
      <option name="">Choose a product:</option>
      <option name="2">Apples</option>
      <option name="1">Bananas</option>
      <option name="3">Oranges</option>
   </select>
   <input type="submit" name="submit" value="Submit" />
</form>
