<?php
   @mysql_connect("localhost","intranetmanager","secret") or die("Could not connect to MySQL server!");
?>
