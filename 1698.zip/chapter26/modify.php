<?php
   if (isset($_POST['submit'])) {
      $rowID = $_POST['rowID'];
      $query = "SELECT name, productid, price, description FROM product WHERE rowID='$rowID'";
      $result = mysql_query($query);
      list($name,$productid,$price,$description) = mysql_fetch_row($result);
      include "modifyform.php";
}
?>
