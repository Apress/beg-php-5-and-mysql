<?php
   $link1 = @mysql_connect("www.somehost.com", "webuser", "abcde") or die("Could not connect to MySQL server!");

   $link2 = @mysql_connect("www.someotherhost.com", "webuser", "secret") or die("Could not connect to MySQL server!");
?>
