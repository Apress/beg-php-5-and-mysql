<?php
   mysql_connect("localhost","webuser","secret");
   echo mysql_get_host_info();
?>
