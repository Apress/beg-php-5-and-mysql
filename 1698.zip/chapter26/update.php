<?php

  @mysql_connect("localhost", "webuser", "secret") or die("Could not connect to MySQL server!");

  @mysql_select_db("company") or die("Could not select database!");


   if (isset($_POST['submit'])) {
      $rowID = $_POST['rowID'];
      $productid = $_POST['productid'];
      $name = $_POST['name'];
      $price = $_POST['price'];
      $description = $_POST['description'];

      $query = "UPDATE product SET productid='$productid', name='$name', price='$price', description='$description' WHERE rowID='$rowID'";
      $result = mysql_query($query);

      if ($result) 
         echo "<p>The product has been successfully updated.</p>";
      else 
         echo "<p>There was a problem updating the product.</p>";
   }



?>