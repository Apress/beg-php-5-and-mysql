<?php

  @mysql_connect("localhost", "webuser", "secret") or die("Could not connect to MySQL server!");

  @mysql_select_db("company") or die("Could not select database!");

   $query = "SELECT productid, name FROM product ORDER BY name";
   $result = mysql_query($query);

   for ($count=0; $count <= mysql_numrows($result); $count++) {
      $productid = mysql_result($result, $count, "productid");
      $name = mysql_result($result, $count, "name");
      echo "$name ($productid) <br />";
   }

?>
