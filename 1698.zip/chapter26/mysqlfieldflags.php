<?php

   mysql_connect("localhost","webuser","secret");
   mysql_select_db("company");

   $query = "SELECT productid as Product_ID, name FROM product ORDER BY name";
   $result = mysql_query($query);
   $row = mysql_fetch_row($result);
   echo mysql_field_flags($result, 0);

?>
