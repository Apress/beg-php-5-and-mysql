<?php

  @mysql_connect("localhost", "webuser", "secret") or die("Could not connect to MySQL server!");

  @mysql_select_db("company") or die("Could not select database!");

   $query = "SELECT productid, name FROM product ORDER BY name";
   $result = mysql_query($query);

   while (list($productid, $name) = mysql_fetch_row($result)) {
      echo "$name ($productid) <br />";
   }

?>
