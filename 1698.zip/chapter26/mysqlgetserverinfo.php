<?php
   mysql_connect("localhost","webuser","secret");
   echo mysql_get_server_info();
?>
