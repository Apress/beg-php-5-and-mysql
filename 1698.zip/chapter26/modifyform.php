<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
   <input type="hidden" name="rowID" value="<?php echo $rowID;?>">
   <p>
      Product ID:<br />
      <input type="text" name="productid" size="8" maxlength="8" value="<?php echo $productid;?>" />
   </p>

   <p>
      Name:<br />
      <input type="text" name="name" size="25" maxlength="25" value="<?php echo $name;?>" />
   </p>

   <p>
      Price:<br />
      <input type="text" name="price" size="6" maxlength="6" value="<?php echo $price;?>" />
   </p>

   <p>
      Description:<br />
      <textarea name="description" rows="5" cols="30">
      <?php echo $description;?></textarea>
   </p>

   <p>
      <input type="submit" name="submit" value="Submit!" />
   </p>
</form>

<?php
   if (isset($_POST['submit'])) {
      $rowID = $_POST['rowID'];
      $productid = $_POST['productid'];
      $name = $_POST['name'];
      $price = $_POST['price'];
      $description = $_POST['description'];

      $query = "UPDATE product SET productid='$productid', name='$name', price='$price', description='$description' WHERE rowID='$rowID'";
      $result = mysql_query($query);

      if ($result) 
         echo "<p>The product has been successfully updated.</p>";
      else 
         echo "<p>There was a problem updating the product.</p>";
   }

?>