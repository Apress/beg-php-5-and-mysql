create table user (
   rowID mediumint unsigned not null auto_increment,
   commonName varchar(35) not null,
   username char(8) not null,
   pswd char(32) not null,
   uniqueIdentifier char(32) not null,
   primary key(rowID)
);
