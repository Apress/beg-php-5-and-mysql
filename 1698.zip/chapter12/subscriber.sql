CREATE TABLE subscriber (
   rowID smallint unsigned not null auto_increment,
   email varchar(55) not null,
   uniqueid char(32) not null,
   readNewsletter ENUM('Y','N') not null default 'N',
   primary key(rowID)
);
