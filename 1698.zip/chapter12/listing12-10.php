<?php
   /*
   Has the user submitted data?
   If not, display the registration form.
   */

   if (! isset($_POST['submitbutton'])) {

      echo file_get_contents("/templates/registration.html");

   /* Form data has been submitted. */
   } else {

      /* Connect to the MySQL server and select database. */
      mysql_connect("localhost", "authenticator", "secret");
      mysql_select_db("chapter12");

      /* Ensure that the password and password verifier match. */
      if ($_POST['pswd'] != $_POST['pswdagain']) {
         echo "<p>The passwords do not match. Please go back and try again.</p>";
      /* Passwords match, so attempt to insert information into user table. */
      } else {
         try {
            $query = "INSERT INTO user SET rowID=NULL, name='$_POST[name]', email='$_POST[email]', username='$_POST[username]', pswd=MD5('$_POST[pswd]')";
            $result = mysql_query($query);
            if (! $result) {
               throw new Exception("Registration problems were encountered!");
            } else {
               echo "<p>Registration was successful!</p>";
            }
         } catch(Exception $e) {
            echo "<p>".$e->getMessage()."</p>";
         } #endCatch
      } #endIF
   } #endIF
?>
