CREATE TABLE user {
   rowID smallint unsigned not null auto_increment,
   name char(40) not null,
   email char(55) not null,
   username char(15) not null,
   pswd char(32) not null,
   primary key(rowID)
);
