create table user (
   rowID tinyint unsigned not null auto_increment,
   commonName varchar(35) not null,
   username varchar(8) not null,
   pswd char(32) not null,
   primary key(rowID) );
