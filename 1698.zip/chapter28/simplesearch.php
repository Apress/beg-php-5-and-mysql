<p>
   Search the employee database:<br />
   <form action="simplesearch.php" method="post">
      Last name:<br />
      <input type="text" name="lastname" size="20" maxlength="40" value="" /><br />
      <input type="submit" value="Search!">
   </form>
</p>

<?php
   // If the form has been submitted with a supplied last name
   if (isset($_POST['lastname'])) {

      include "mysql.class.php";
      // Connect to server and select database
      $mysqldb = new mysql("localhost","jason","secret","company");
      $mysqldb->connect();
      $mysqldb->select();

      // Set the posted variable to a convenient name
      $lastname = $_POST['lastname'];

      // Query the employee table
      $mysqldb->query("SELECT firstname, lastname, email FROM employee WHERE lastname='$lastname'");

      // If records found, output firstname, lastname, and email field of each
      if ($mysqldb->numrows() > 0) {
         while ($row = $mysqldb->fetchobject())
            echo "$row->lastname, $row->firstname ($row->email)<br />";
      } else {
         echo "No results found.";
      }
   }
?>
