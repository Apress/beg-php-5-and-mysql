<p>
   Search the online resources database:<br />
   <form action="fulltextsearch.php" method="post">
      Keywords:<br />
      <input type="text" name="keywords" size="20" maxlength="40" value="" /><br />
      <input type="submit" value="Search!">
   </form>
</p>

<?php
   // If the form has been submitted with supplied keywords
   if (isset($_POST['keywords'])) {
      include "mysql.class.php";
      // Connect to server and select database
      $mysqldb = new mysql("localhost","root","","company");
      $mysqldb->connect();
      $mysqldb->select();
      $keywords = $_POST['keywords'];

      // Create the query
      $mysqldb->query("SELECT name, url FROM webresource WHERE MATCH(description) AGAINST('$keywords')");
   
      // Output retrieved rows or display appropriate message
      if ($mysqldb->numrows() > 0) {
         while ($row = $mysqldb->fetchobject())
            echo "<a href=\"$row->url\">$row->name</a><br />";
      } else {
         echo "No results found.";
      }
   }
?>
