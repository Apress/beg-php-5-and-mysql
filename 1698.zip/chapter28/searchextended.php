<p>
   Search the employee database:<br />
   <form action="searchextended.php" method="post">
      Keyword:<br />
      <input type="text" name="keyword" size="20" maxlength="40" value="" /><br />
      Field:<br />
      <select name="field">
         <option value="">Choose field:</option>
         <option value="lastname">Last Name</option>
         <option value="email">Email Address</option>
      </select>
      <input type="submit" value="Search!">
   </form>
</p>

<?php
   // If the form has been submitted with a supplied keyword
   if (isset($_POST['field'])) {

      include "mysql.class.php";

      // Connect to server and select database
      $mysqldb = new mysql("localhost","jason","secret","company");
      $mysqldb->connect();
      $mysqldb->select();

      // Set the posted variables to a convenient names
      $keyword = $_POST['keyword'];
      $field = $_POST['field'];

      // Create the query
      if ($field == "lastname" ) {
         $mysqldb->query("SELECT firstname, lastname, email FROM employee WHERE lastname='$keyword'");
      } elseif ($field == "email") {
         $mysqldb->query("SELECT firstname, lastname, email FROM employee WHERE email='$keyword'");
      }

      // If records found, output firstname, lastname, and email field of each
      if ($mysqldb->numrows() > 0) {
         while ($row = $mysqldb->fetchobject())
            echo "$row->lastname, $row->firstname ($row->email)<br />";
      } else {
         echo "No results found.";
      }
   }

?>
