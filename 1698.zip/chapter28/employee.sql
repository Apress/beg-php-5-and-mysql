create table employee (
rowID smallint unsigned not null auto_increment,
lastname varchar(35) not null,
firstname varchar(35) not null,
email varchar(55) not null unique,
city varchar(100) not null,
index name (lastname, firstname),
primary key(rowID));
