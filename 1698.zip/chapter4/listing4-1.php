<?php
   function amortizationTable($paymentNum, $periodicPayment, $balance, $monthlyInterest) {
      $paymentInterest = round($balance * $monthlyInterest,2);
      $paymentPrincipal = round($periodicPayment - $paymentInterest,2);
      $newBalance = round($balance - $paymentPrincipal,2);
      print "<tr>
         <td>$paymentNum</td>
         <td>\$".number_format($balance,2)."</td>
         <td>\$".number_format($periodicPayment,2)."</td>
         <td>\$".number_format($paymentInterest,2)."</td>
         <td>\$".number_format($paymentPrincipal,2)."</td>
      </tr>";
      # If balance not yet zero, recursively call amortizationTable()
      if ($newBalance > 0) {
         $paymentNum++;
         amortizationTable($paymentNum, $periodicPayment, $newBalance, $monthlyInterest);
      } else {
         exit;
      }
   } #end amortizationTable()
?>