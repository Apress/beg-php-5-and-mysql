<?php
   echo "Five raised to the third power equals ".pow(5,3).".";
?>
