<?php
   function generate_footer() {
      echo "<p>Copyright &copy; 2003-2004 W. Jason Gilmore</p>";
   }

   generate_footer();
?>
