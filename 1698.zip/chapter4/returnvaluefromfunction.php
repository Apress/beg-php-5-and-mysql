<?php
function salestax($price,$tax=.0575) {
return $price + ($price * $tax);
}

$price = 6.50;
$total = salestax($price);


?>