<?php
function salestax($price,$tax) {
$total = $price + ($price * $tax);
echo "Total cost: $total";
}

salestax(15.00,.075);

?>
