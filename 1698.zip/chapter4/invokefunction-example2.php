<?php
   echo pow(5,3);
?>
