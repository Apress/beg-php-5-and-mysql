<?php
   function calculate($price,$price2="",$price3="") {
      echo $price + $price2 + $price3;
   }

   calculate(10,"",3);

?>