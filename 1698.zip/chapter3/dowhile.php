<?php
$count = 11;
do {
echo "$count squared = ".pow($count,2). "<br />";
} while ($count < 10);
?>
