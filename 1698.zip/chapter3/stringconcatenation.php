<?php
   // $a contains the string value "Spaghetti & Meatballs";
   $a = "Spaghetti" . "& Meatballs";
   $a .= " are delicious";
   // $a contains the value "Spaghetti & Meatballs are delicious."
?>