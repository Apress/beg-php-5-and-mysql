<?php
   $total = 5;
   $count = "15";
   $total += $count; // $total = 20;
?>
