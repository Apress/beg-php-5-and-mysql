<?php
   $secretNumber = 453;
   if ($_POST[�guess�] == $secretNumber) echo "<p>Congratulations! You guessed it!</p>";
?>
