<h3>Welcome!</h3>

<?php
   print "<p>This is a PHP example.</p>";
?>

<p>Some static information found here...</p>
