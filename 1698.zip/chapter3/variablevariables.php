<?php
   $recipe = "spaghetti";
   $$recipe = "& meatballs";
   print $recipe $spaghetti;
   print $recipe ${$recipe};
?>