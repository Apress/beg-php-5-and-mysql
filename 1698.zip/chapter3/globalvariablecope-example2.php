<?php
   $somevar = 15;
   function addit() {
      $GLOBALS["somevar"]++;
   }
   addit();
   print "Somevar is ".$GLOBALS["somevar"];
?>