<?php
   $total = "1.0";
   if ($total) echo "The total count is positive";
?>
