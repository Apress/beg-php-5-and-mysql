<?php
   printf("$%01.2f", 43.2); // $43.20
   printf("%d bottles of beer on %s", 100, "the wall");
   // 100 bottles of beer on the wall
   printf("%15s", "Some text"); // Some text
?>