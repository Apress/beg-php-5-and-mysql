<?php
   $secretNumber = 453;
   if ($_POST[�guess�] == $secretNumber) {
      echo "<p>Congratulations! You guessed it!</p>";
   } else {
      echo "<p>Sorry. Apparently you lack psychic powers!</p>";
   }
?>
