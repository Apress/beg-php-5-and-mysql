<?php
   echo 'This string will $print exactly as it\'s \n declared.';
?>