<?php
   printf("The %2\$s likes to %1\$s", "bark", "dog"); // The dog likes to bark
   printf("The %1\$s says: %2\$s, %2\$s.", "dog", "bark");
   // The dog says: bark, bar.
?>
