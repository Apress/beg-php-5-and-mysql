<?="This is another PHP example.";?>
