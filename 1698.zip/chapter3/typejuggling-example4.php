<?php
   $val1 = "1.2e3";
   $val2 = 2;
   echo $val1 * $val2; // outputs 2400
?>
