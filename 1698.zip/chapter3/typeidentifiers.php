<?php
   $item = 43;
   echo "The variable \$item is of type array: ".is_array($item)."<br />";
   echo "The variable \$item is of type integer: ".is_integer($item)."<br />";
   echo "The variable \$item is numeric: ".is_numeric($item)."<br />";
?>
