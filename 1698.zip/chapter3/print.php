<?php
   print("<p>I love the summertime.</p>");
?>

<?php
   $season = "summertime";
   print "<p>I love the $season.</p>";
?>

<?php
   print "<p>I love the
   summertime.</p>";
?>

<?php
   $season = "summertime";
   print "<p>I love the ".$season."</p>";
?>
