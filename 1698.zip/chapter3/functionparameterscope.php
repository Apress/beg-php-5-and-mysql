<?php
   // multiply a value by 10 and return it to the caller
   function x10 ($value) {
      $value = $value * 10;
      return $value;
   }
?>