<?php
   // Example One
   for ($kilometers = 1; $kilometers <= 5; $kilometers++) {
      echo "$kilometers kilometers = ".$kilometers*0.62140. " miles. <br />";
   }
?>