<?php
   // Example Three
   $kilometers = 1;
   for (;;) {
      if ($kilometers > 5) break;
         echo "$kilometers kilometers = ".$kilometers*0.62140. " miles. <br />";
      $kilometers++;
   }
?>