<script language="php">
   print "This is another PHP example.";
</script>
