<?php
   $sport = "boxing";
   echo "Jason�s favorite sport is $sport.";
?>