<?php
   function cubed($value) {
      return $value * $value * value;
   }

  echo cubed(3);
?>