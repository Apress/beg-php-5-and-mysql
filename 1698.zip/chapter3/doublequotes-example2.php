<?php
   $output = "This is one line.\nAnd this is another line.";
   echo $output;
?>
