<?php
   $total = "45 fire engines";
   $incoming = 10;
   $total = $incoming + $total; // $total = 55
?>
