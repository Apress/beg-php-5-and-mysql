<?php
   $sqldb = sqlite_open("pmnp.db");

   // Perform necessary tasks

   sqlite_close($sqldb);

?>
