<?php
   $sqldb = sqlite_open("pmnp.db") or die("Could not connect!");
?>
