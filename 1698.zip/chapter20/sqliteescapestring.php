<?php
   $str = "As they always say, this is 'an' example.";
   echo sqlite_escape_string($str);
?>
