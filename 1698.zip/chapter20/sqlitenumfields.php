<?php

   $sqldb = sqlite_open("pmnp.db");

   $results = sqlite_query($sqldb, "SELECT * FROM employee");
   echo "Total fields returned: ".sqlite_num_fields($results)."<br />";

   sqlite_close($sqldb);

?>
