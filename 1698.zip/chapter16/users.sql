CREATE table users (
   userid mediumint UNSIGNED NOT NULL AUTO_INCREMENT,
   name varchar(25) NOT NULL,
   username varchar(15) NOT NULL,
   pswd varchar(15) NOT NULL,
   PRIMARY KEY(userid));
