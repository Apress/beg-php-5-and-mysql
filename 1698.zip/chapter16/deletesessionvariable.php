<?php

   session_start();

   $_SESSION['username'] = "jason";
   echo "Your username is: ".$_SESSION['username'].".<br />";
   
   /* Delete the session variable. */
   unset($_SESSION['username']);

   /* Demonstrate that session variable is indeed gone. */
   echo "Username now set to: ".$_SESSION['username'].".";

?>
