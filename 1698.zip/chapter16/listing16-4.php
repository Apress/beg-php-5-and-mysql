<?php

   session_start();

   // Has a session been initiated previously?
   if (! isset($_SESSION['name'])) {
      // If no previous session, has the user submitted the form?
      if (isset($_POST['username'])) {
         $username = $_POST['username'];
         $pswd = $_POST['pswd'];

         // Connect to the MySQL server and select the database
         mysql_connect("localhost","webuser","secret");
         mysql_select_db("chapter16");

         // Look for the user in the users table.
         $query = "SELECT name FROM users WHERE username='$username' AND pswd='$pswd'";
         $result = mysql_query($query);

         // If the user was found, assign some session variables.
         if (mysql_numrows($result) == 1) {
            $_SESSION['name'] = mysql_result($result,0,"name");
            $_SESSION['username'] = mysql_result($result,0,"username");
            echo "You're logged in. Feel free to return at a later time.";
         }
         // If the user has not previously logged in, show the login form
         } else {
            include "login.html";
         }

      // The user has returned. Offer a welcoming note.
      } else {
         $name = $_SESSION['name'];
         echo "Welcome back, $name!";
      }
?>
