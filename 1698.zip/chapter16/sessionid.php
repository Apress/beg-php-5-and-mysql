<?php
   session_start ();
   print "Your session identification number is ".session_id();
?>
