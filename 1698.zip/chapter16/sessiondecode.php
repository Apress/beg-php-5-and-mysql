<?php

   /* Start the new session. */
   session_start();

   /* What is the user's session ID? */
   $sid = session_id();

   /* Connect to the MySQL server and select the database. */
   mysql_connect("localhost","user","secret");
   mysql_select_db("chapter16");

   /* Select data from the usersession table. */
   $query = "SELECT data FROM usersession WHERE sid='$sid'";
   $result = mysql_query($query);

   /* Assign the encoded row to a variable. */
   $sessionVars = mysql_result($result,0,"data");
   
   /* Decode the row. */
   session_decode($sessionVars);
 
   /* The variables are now available for use. */
   echo "User ".$_SESSION['username']." logged on at ".$_SESSION['loggedon'].".";
?>
