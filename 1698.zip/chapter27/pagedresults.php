<?php

   include "mysql.class.php";

   $mysqldb = new mysql("localhost","jason","secret","company");
   $mysqldb->connect();
   $mysqldb->select();

   // Set number entries per page
   $pagesize = 2;

   // What is our record offset?
   $recordstart = (isset($_GET['recordstart'])) ? $_GET['recordstart'] : 0;

   // Execute the SELECT query, including a LIMIT clause
   $mysqldb->query("SELECT name, price FROM product ORDER BY name LIMIT $recordstart, $pagesize");

   // Output the result set
   $actions = '<a href="viewdetail.php?rowid=VALUE">View Detailed</a> | <a href="addtocart.php?rowid=VALUE">Add to Cart</a>';
   echo $mysqldb->getResultAsTable($actions);

   // Determine whether additional rows are available
   $mysqldb->query("select count(rowID) as count FROM product");
   $row = $mysqldb->fetchObject();
   $totalrows = $row->count;

   // Create the 'previous' link
   if ($recordstart > 0) {
      $prev = $recordstart - $pagesize;
      $url = $_SERVER['PHP_SELF']."?recordstart=$prev";
      echo "<a href=\"$url\">Previous Page</a> ";
   }

   // Create the 'next' link
   if ($totalrows > ($recordstart + $pagesize)) {
      $next = $recordstart + $pagesize;
      $url = $_SERVER['PHP_SELF']."?recordstart=$next";
      echo "<a href=\"$url\">Next Page</a>";
   }

?>
