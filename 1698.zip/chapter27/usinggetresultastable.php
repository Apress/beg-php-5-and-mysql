<?php

   include "mysql.class.php";

   $mysqldb = new mysql("localhost","jason","secret","company");
   $mysqldb->connect();
   $mysqldb->select();

   // Execute the query
   $mysqldb->query("SELECT name as Product, price as Price, description as Description FROM product");

   // Return the result as a table
   echo $mysqldb->getResultAsTable();

?>
