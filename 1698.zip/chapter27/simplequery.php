<?php

   include "mysql.class.php";

   // Create new mysql object
   $mysqldb = new mysql("localhost","jason","secret","company");

   // Connect to database server and select database
   $mysqldb->connect();
   $mysqldb->select();

   // Query the database
   $mysqldb->query("SELECT name, price FROM product WHERE productid='tshirt01'");

   // Retrieve query result as an object
   $row = $mysqldb->fetchObject();

   // Output the data
   echo "$row->name (\$$row->price)";

?>
