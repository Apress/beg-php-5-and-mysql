<?php

   include "mysql.class.php";

   // Create new mysql object
   $mysqldb = new mysql("localhost","jason","secret","company");

   // Connect to database server and select database
   $mysqldb->connect();
   $mysqldb->select();

   // Execute a few queries
   $query = "SELECT name, price FROM product ORDER BY name";
   $mysqldb->query($query);

   $query2 = "SELECT name, price FROM product WHERE productid='tshirt01'";
   $mysqldb->query($query2);

   // Output the total number of queries executed.
   echo "Total number of queries executed: ".$mysqldb->numQueries()." <br />";

?>

