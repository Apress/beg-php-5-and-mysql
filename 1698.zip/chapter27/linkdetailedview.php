<?php

   include "mysql.class.php";

   $mysqldb = new mysql("localhost","jason","secret","company");
   $mysqldb->connect();
   $mysqldb->select();

   $mysqldb->query("SELECT rowID, name as Product, price as Price FROM product ORDER BY name");

   $actions = '<a href="viewdetail.php?rowid=VALUE">View Detailed</a> | <a href="addtocart.php?rowid=VALUE">Add to Cart</a>';

   echo $mysqldb->getResultAsTable($actions);

?>
