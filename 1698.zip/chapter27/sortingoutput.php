<?php

   include "mysql.class.php";

   $mysqldb = new mysql("localhost","jason","secret","company");
   $mysqldb->connect();
   $mysqldb->select();

   // Determine what kind of sort request has been submitted.
   // By default this is set to sort by name
   $sort = (isset($_GET['sort'])) ? $_GET['sort'] : "name";

   // Query the database
   $mysqldb->query("SELECT rowID, name as Product, price as Price FROM product ORDER BY $sort ASC");

   $actions = '<a href="viewdetail.php?rowid=VALUE">View Detailed</a> | <a href="addtocart.php?rowid=VALUE">Add to Cart</a>';

   echo $mysqldb->getResultAsTable($actions);

?>
