<?php

   include "mysql.class.php";

   // Create new mysql object
   $mysqldb = new mysql("localhost","jason","secret","company");

   // Connect to database server and select database
   $mysqldb->connect();
   $mysqldb->select();

   // Query the database
   $mysqldb->query("SELECT name, price FROM product ORDER BY name");

   // Output the data
   while ($row = $mysqldb->fetchObject())
      echo "$row->name (\$$row->price)<br />";
?>

