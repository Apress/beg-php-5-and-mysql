<?php

   function delete_directory($dir) {

      if ($dh = @opendir($dir)) {

      /* Iterate through directory contents. */
      while (($file = readdir ($dh)) != false) {
         if (($file == ".") || ($file == "..")) continue;
            if (is_dir($dir . '/' . $file))
               delete_directory($dir . '/' . $file);
            else
               unlink($dir . '/' . $file);
      } #endWHILE

      @closedir($dh);
      rmdir($dir);
      } #endIF
   } #end delete_directory()

$dir = "/usr/local/apache2/htdocs/book/chapter10/test/";

delete_directory($dir);

?>
