<?php
   $result = `date`;
   echo "<p>The server timestamp is: $result</p>";
?>
