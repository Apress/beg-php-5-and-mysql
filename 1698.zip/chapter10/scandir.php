<?php
   print_r(scandir("/usr/local/apache2/htdocs"));
?>
