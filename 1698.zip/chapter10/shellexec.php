<?php
   $result = shell_exec("date");
   echo "<p>The server timestamp is: $result</p>";
?>
