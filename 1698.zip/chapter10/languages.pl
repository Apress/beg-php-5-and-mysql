#! /usr/bin/perl
my @languages = qw[perl php python java c];
foreach $language (@languages) {
   print $language."<br />";
}
