<?php
   $outcome = exec("languages.pl", $results);
   echo $outcome
?>
