<?php
   $subscriberInfo = "Jason Gilmore|wj@wjgilmore.com";
   $fh = fopen("/home/www/data/subscribers.txt", "at");
   fwrite($fh, $subscriberInfo);
   fclose($fh);
?>
