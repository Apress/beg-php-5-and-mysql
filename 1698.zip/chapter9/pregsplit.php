<?php
   $delimitedText = "+Jason+++Gilmore+++++++++++Columbus+++OH";
   $fields = preg_split("/\+{1,}/", $delimitedText);
   foreach($fields as $field) echo $field."<br />";
?>
