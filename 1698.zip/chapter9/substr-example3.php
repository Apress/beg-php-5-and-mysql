<?php
   $car = "1944 Ford";
   $yr = echo substr($car, 2, -5);
?>
