<?php
   $car = "1944 Ford";
   echo substr($car, 0, 4);
?>
